# DOM Assignment 5

### Task1: Adding 'Pro Subscription Button'

![Pro Subscription Button added](./Solution_Image/Assignment_5_Task_1.png)

```JavaScript
let nav = document.querySelectorAll('.nav-center div');
undefined
nav
NodeList(3) [div.nav-header, div.nav-links, div]
let arr = Array.from(nav);
undefined
let btn = document.createElement('btn');
undefined
btn.innerText = 'Pro Subscription';
'Pro Subscription'
arr[2].appendChild(btn);
<btn>​Pro Subscription​</btn>​
btn.className = 'btn';
'btn'
```
---

### Task2: Adding 'Chinese(7)' to Recipes

![Pro Subscription Button added](./Solution_Image/Assignment_5_Task_2.png)

```JavaScript
let recipes_div = document.querySelector('.tags-container div');
undefined
let aTag = document.createElement('a');
undefined
aTag.href="#";
'#'
aTag
<a href=​"#">​</a>​
aTag.innerText = "Chinese (7)";
'Chinese (7)'
aTag
<a href=​"#">​Chinese (7)​</a>​
recipes_div.appendChild(aTag);
<a href=​"#">​Chinese (7)​</a>​

```
---

### Task3: Chanding font color for Cards (h5, p)

![Pro Subscription Button added](./Solution_Image/Assignment_5_Task_3.png)

```JavaScript
let cards_h5 = document.querySelectorAll('.card h5');
undefined
array_h5 = Array.from(cards_h5);
(5) [h5.recipe-name, h5.recipe-name, h5.recipe-name, h5.recipe-name, h5.recipe-name]
for(let i=0; i<array_h5.length; i++){
array_h5[i].style.color ='blueviolet';
};
'blueviolet'
let cards_p = document.querySelectorAll('.card p');
undefined
array_p = Array.from(cards_p);
(5) [p.recipe-disp, p.recipe-disp, p.recipe-disp, p.recipe-disp, p.recipe-disp]
for(let i=0; i<array_p.length; i++){
array_p[i].style.color ='blueviolet';
};
```
---

### Task4: Adding 6th Card Placehodler

![Pro Subscription Button added](./Solution_Image/Assignment_5_Task_4.png)

```JavaScript
let recipe_gallery = document.querySelector('.recipe-gallery');
undefined
let newDiv = document.createElement('div');
undefined
newDiv.className = 'card';
'card'
newDiv.innerText ='add 6th card here';
'add 6th card here'
recipe_gallery.appendChild(newDiv);
<div class=​"card">​add 6th card here​</div>​
newDiv.style.fontWeight='bold';
```
