# DOM Assignment-7

## Task-1 & 2

![DOM Assignment-7 Task-1&2](./Solution_Img/Assignment7_Task1%262_Part-1.png)

![DOM Assignment-7 Task-1&2](./Solution_Img/Assignment7_Task1%262_Part-2.png)

![DOM Assignment-7 Task-1&2](./Solution_Img/Assignment7_Task1%262_Part-3.png)

```JavaScript

let main_languages = document.querySelectorAll('.main__languages a');
let array_languages = Array.from(main_languages);

for(let i=0; i<array_languages.length; i++){

    if(array_languages[i].textContent.includes('2.0')){
        array_languages[i].style.display ="none";
    }
};

let inputBox = document.querySelector('.main__form-input');
inputBox.disabled = false;
inputBox.value = 'Text entered through JS DOM';

let btn = document.querySelector('.main__form-btn');
btn.disabled = false;

let form = document.querySelector('form');
setInterval(() => {form.submit()},10000);

```

---
