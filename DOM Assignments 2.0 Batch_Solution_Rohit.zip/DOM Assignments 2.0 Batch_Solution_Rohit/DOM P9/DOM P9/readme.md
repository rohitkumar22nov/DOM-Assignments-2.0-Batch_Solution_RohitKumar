# DOM Assignment-9

### Task-1 (Text Color Red)

![Task-1 Text Color Red](./solution_img/Assignment09_Task01.png)

```JavaScrip

let h1 = document.querySelector('h1');
h1.style.color ='Red';

```
---

### Task-2 ('Add to cart' button color change )

![Task-2 Text Color Red](./solution_img/Assignment09_Task02.png)

```JavaScript

let add_to_cart = document.querySelector('.add-to-cart');
add_to_cart.style.backgroundColor = 'Red';

```