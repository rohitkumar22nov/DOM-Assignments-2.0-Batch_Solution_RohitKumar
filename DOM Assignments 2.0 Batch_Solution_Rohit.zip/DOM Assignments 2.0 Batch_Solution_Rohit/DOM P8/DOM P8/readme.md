# DOM Assignment 8
### Task-1 (Adding a scroll to sidebar)

![Task1 - Adding scroll to sidebar](./solution_img/Assignment8_Task1.png)

```JavaScript
let aside = document.querySelector('aside');
aside.style.overflowY='scroll';
```
---

### Task-2 (Removing background from body)

![Task2 - Background removed from body](./solution_img/Assignment8_Task2.png)

```JavaScript
document.body.style.backgroundImage = "url('')";
```
---

### Task-3 (Navbar changes)

![Task2 - Navbar changes](./solution_img/Assignment8_Task3.png)

```JavaScript
let btn = document.querySelector('.navbar button');
btn.style.border='solid 8px';

let nav_div = document.querySelector('.navbar div');
nav_div.style.display = 'block';

```
---
