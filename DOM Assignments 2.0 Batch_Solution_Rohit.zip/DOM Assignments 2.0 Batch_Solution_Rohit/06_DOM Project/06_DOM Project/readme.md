# DOM Assignment 6

### Task 1 (Removing Premium EQ patch)

![DOM Assignment 6 Task-1](./solution_image/Assignment6_Task1.png)

```JavaScript
let divs = document.querySelectorAll('.app div');
undefined
let arr1 = Array.from(divs);
undefined
arr1[1].className ='';
arr1[1].style.display='none';

let logo = document.querySelector('header img');
undefined
logo.src = "./assets/ineuron-logo.png";
'./assets/ineuron-logo.png'

let main = document.querySelector('main');
main.style.backgroundImage = "url('./assets/bg-main-desktop.png')";
"url('./assets/bg-main-desktop.png')"


document.body.style.backgroundImage = "url('./assets/bg-main.desktop.png')";


```

--- 


### Task 2 (Removing Premium EQ patch, giving background color and adding iNeuron logo)

![DOM Assignment 6 Task-1](./solution_image/Assignment6_Task2.png)

```JavaScript
let top_img = document.querySelector('.top_img');
let header = document.querySelector('header');
let hero = document.querySelector('.hero');
undefined
top_img.style.display = "none";
'none'
header.style.display = "none";
'none'
hero.style.display = "none";
'none'
let app_price = document.querySelector('.app_price span');
undefined
app_price.innerText = '$10';
'$10'

```
---


