# DOM Assignment 1

### Task 1

### After Update

![DOM Assignment 1 - Task-1 Solution](./solution_images/DOM_Assignment_Task1_Solved.png)

### Project Solution
---
```JavaScript
const li_New = document.createElement('li');
const ul = document.querySelector('ul');
li_New.innerHTML = '<a href="#"> Hire ME</a>'
ul.appendChild(li_New);
<li>​…​</li>​<a href=​"#">​ Hire ME​</a>​</li>​
```
---

### Task 2

### After Update

![DOM Assignment 1 - Task-2 Solution](./solution_images/DOM_Assignment_Task2_Solved.png)

### Project Solution

```javascript
let ul = document.querySelector('ul');
let ul_li = document.querySelector('ul li');
let li_all = document.getElementsByTagName('li');
li_all[2].innerText = 'Projects'
```
---
### Task 3

### After Update

![DOM Assignment 1 - Task-3 Solution](./solution_images/DOM_Assignment_Task3_Solved.png)

### Project Solution

```JavaScript
let p_span = document.querySelectorAll('p span');
p_span[1].innerText = 'an Employee';
p_span[2].innerText = 'iNeuron intelligence Pvt. Ltd.';
```
---

### Task 4

### After Update

![DOM Assignment 1 - Task-4 Solution](./solution_images/DOM_Assignment_Task4_Solved.png)

### Project Solution

```JavaScript
let img_div = document.querySelector('.hero-right-section img');
img_div.src = "./solution_images/profile_image_Rohit.png";
```
---

### Task 5

### After Update

![DOM Assignment 1 - Task-5 Solution](./solution_images/DOM_Assignment_Task5_Solved.png)

### Project Solution

```JavaScript
let btn = document.createElement('button');
btn.innerText = 'Support Me';
let btn_div = document.querySelector('.hero-right-section-btns');
btn_div.appendChild(btn);
```

---

# DOM Assignment 2

### Task 1

### After Update

![DOM Assignment 2 - Task-1 Solution](./solution_images/DOM_Second_Assignment_Task1_Solved.png)

### Project Solution
```JavaScript
let div_target = document.querySelectorAll('.accordian h3');
div_target;
let arr = Array.from(div_target);
for(let i=0; i<arr.length; i++){
    arr[i].style.backgroundColor='#D3D3D3'}

```

### Task 2

### After Update

![DOM Assignment 2 - Task-2 Solution](./solution_images/DOM_Second_Assignment_Task2_Solved.png)

### Project Solution

```JavaScript

let accordianDiv = document.createElement('div');
accordianDiv.className ='accordian';
let h3Tag = document.createElement('h3');
h3Tag.innerText='Skills'
let pTag = document.createElement('p');
pTag.innerText='I posses a very good command over the Full Stack Developement technologies like MERN which can be seen in my work over the Github'
let mainDiv = document.querySelector('.accordian-wrapper');
accordianDiv.appendChild(h3Tag);
accordianDiv.appendChild(pTag);
mainDiv.appendChild(accordianDiv);


h3Tag.addEventListener('click', () =>{

if(pTag.style.display === 'none'){
pTag.style.display = 'block';
}
else{
pTag.style.display = 'none';
    }

});

````
---
# DOM Assignment 3

### Task 1

### After Update

![DOM Assignment 3 - Task-1 Solution](./solution_images/DOM_Third_Assignment_Task1_Solved.png)

### Project Solution
```JavaScript

let left_input = document.querySelectorAll('.mainLeftDetails input');
let arr1 = Array.from(left_input);
arr1[0].placeholder ='FSJS 2.0';
arr1[1].placeholder ='fsjs@ineuron.ai';
let left_text = document.querySelector('.enterMessage');
left_text.placeholder = 'Hello World';



let right_input = document.querySelectorAll('.mainRight input');
let arr2 = Array.from(right_input);
arr2[0].placeholder ='FSJS 2.0';
arr2[1].placeholder ='fsjs@ineuron.ai';
let right_text = document.querySelector('.userMessage');
right_text.placeholder = 'Hello World';
'Hello World'

```
---



