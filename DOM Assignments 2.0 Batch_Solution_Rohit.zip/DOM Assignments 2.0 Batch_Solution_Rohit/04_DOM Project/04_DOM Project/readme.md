# DOM Assignment 4

### Task 1

### After Update

![DOM Assignment 4 - Task-1 Solution](./Solution_Image/Assignment_4_Task_1.png)

### Project Solution
---
```JavaScript
​let cards = document.querySelectorAll('.clash-card__unit-stats');
let arr1 = Array.from(cards);
arr1[0].style.backgroundColor = '#FFA500';
arr1[0].style.color = '#FFFFFF';
let font1 = document.querySelectorAll('.one-third');
let arr2 = Array.from(font1);
arr2[2].style.color = '#FFFFFF';
arr1[1].style.backgroundColor = '#FF1493';
arr1[1].style.color = '#FFFFFF';
arr2[5].style.color ='#FFFFFF';
arr1[2].style.backgroundColor = '#FFA500';
arr1[2].style.color = '#FFFFFF';
arr2[8].style.color = '#FFFFFF';
arr1[3].style.backgroundColor = '#90EE90';
arr1[3].style.color = '#FFFFFF';
arr2[11].style.color = '#FFFFFF';
arr1[4].style.backgroundColor = '#0000FF';
arr1[4].style.color = '#FFFFFF';
arr2[14].style.color = '#FFFFFF';
```
---